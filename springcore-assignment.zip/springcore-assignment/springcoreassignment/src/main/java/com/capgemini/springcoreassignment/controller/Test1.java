package com.capgemini.springcoreassignment.controller;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.capgemini.springcoreassignment.bean.MessageBean;
import com.capgemini.springcoreassignment.config.MessageConfig;

public class Test1 {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context=	new AnnotationConfigApplicationContext(MessageConfig.class);

		 MessageBean msgbean=context.getBean(MessageBean.class); 
		 msgbean.print();
	}

}
