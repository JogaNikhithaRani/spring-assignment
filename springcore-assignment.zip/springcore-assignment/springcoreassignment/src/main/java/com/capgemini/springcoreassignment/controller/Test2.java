package com.capgemini.springcoreassignment.controller;

public class Test2 {

}
